﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Bus_Booking_System_DAO
{
    public class BookBusLocViewModel
    {
        public Booking Booking { get; set; }
        public Bus Bus { get; set; }
        public Location Location { get; set; }
    }
}
